use anlysis;
select * from hr_1 ;
select * from hr_2;

alter table hr_1
change column `attrition Value` Attrition_value int;



-- Average Attrition rate for all Departments --

select department,avg(Attrition_value) as Avg_Att
from Hr_1
group by department;


-- Average Hourly rate of Male Research Scientist --
select jobrole,avg(hourlyrate)
from hr_1
where
jobrole = 'research scientist'
and
gender = 'Male';

-- Attrition rate Vs Monthly income stats --
select t1.department,avg(t1.attrition_value),t2.monthlyincome
from hr_1 t1
join hr_2 t2 on t1.employeenumber = t2.`employee id`
group by t1.department;

-- Average working years for each Department --
select t1.department,avg(t2.totalworkingyears)
from hr_1 t1
join hr_2 t2 on t1.employeenumber = t2.`employee id`
group by t1.department;

-- Job Role Vs Work life balance --
select t1.jobrole,t2.worklifebalance
from hr_1 t1
join hr_2 t2 on t1.employeenumber = t2.`employee id`
group by t1.jobrole;

-- Attrition rate Vs Year since last promotion relation --
select t1.attrition_value,t2.yearssincelastpromotion
from hr_1 t1
join hr_2 t2 on t1.employeenumber = t2.`employee id`
;


